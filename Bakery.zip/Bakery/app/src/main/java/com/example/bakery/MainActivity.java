package com.example.bakery;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.bakery.DataItems;
import com.example.bakery.R;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemClickListener {

    ListView lv;
    ImageView imgCart;
    TextView cartItemsCount,txtwelcome;
    ArrayList<DataItems> dataItemsArrayList=new ArrayList<>();
    static int i;
String name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_main);

        name= getIntent().getStringExtra("name");
        lv=findViewById(R.id.lvitems);
        txtwelcome=findViewById(R.id.txtwelcome);

        txtwelcome.setText("Welcome "+ name);
        imgCart=findViewById(R.id.cart);
        cartItemsCount=findViewById(R.id.cartitemscount);

        filldata();
        lv.setAdapter(new Adaptor(this,dataItemsArrayList));


        lv.setOnItemClickListener(this);
        imgCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this,Cart.class));
            }
        });
    }

    public void filldata(){
        dataItemsArrayList.add(new DataItems("Cake","cake",8.99,"2 eggs,2 teaspoons vanilla extract,1 ½ cups all-purpose flour,1 ¾ teaspoons baking powder,½ cup milk"));
        dataItemsArrayList.add(new DataItems("Coffee","coffee",1.59,"1 cup (240 mL) hot water ,1 to 2 teaspoons instant coffee , 1 to 2 teaspoons sugar (optional),Milk or creamer ,Cocoa, spices, or vanilla extract (optional)"));
        dataItemsArrayList.add(new DataItems("Donut","donut",0.99,"flour, baking powder, salt, liquid, and varying amounts of eggs, milk, sugar, shortening and other flavorings. "));
        dataItemsArrayList.add(new DataItems("Ice Cream","ice",12.99,"Ice cream is a colloidal emulsion made with water, ice, milk fat, milk protein, sugar and air."));
        dataItemsArrayList.add(new DataItems("Chocolava","lava",4.99,"Butter, Egg, Sugar, Chocolate,Baking powder"));
        dataItemsArrayList.add(new DataItems("Muffin","muffin",1.95,"flour, sieved together with bicarbonate of soda as a raising agent. To this is added butter or shortening, eggs and any flavourings (fruit, such as blueberries, chocolate or banana; or savouries, such as cheese)."));
        dataItemsArrayList.add(new DataItems("Pastry","pastry",2.20,"flour, sugar, milk, shortening, baking powder and eggs. When these ingredients are combined to form a dough that is flakier or crumblier than bread dough."));
        dataItemsArrayList.add(new DataItems("Pie","pie",3.47,"2 eggs , pumpkin puree, sweetened condensed milk,teaspoon pumpkin pie spice,unbaked pie crust"));
    }


    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Intent detail = new Intent(MainActivity.this,DetailItem.class);
        detail.putExtra("itemname",dataItemsArrayList.get(position).getProdName());
        detail.putExtra("itemprice",dataItemsArrayList.get(position).getProdPrice()+"");
        detail.putExtra("itemingredient",dataItemsArrayList.get(position).getProdIngredients());
        detail.putExtra("itemimage",dataItemsArrayList.get(position).getProImage());
        startActivity(detail);
    }
    public void itemcount(){
        i=CartUtility.itemsCarts.size();
        cartItemsCount.setText(String.valueOf(i));
    }

    @Override
    protected void onResume() {
        super.onResume();
        itemcount();
    }
}