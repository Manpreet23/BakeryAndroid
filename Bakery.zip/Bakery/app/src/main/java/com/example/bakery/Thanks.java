package com.example.bakery;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class Thanks extends AppCompatActivity implements View.OnClickListener {
ImageView iv_back;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_thanks);

        iv_back=findViewById(R.id.imageView4);

        iv_back.setOnClickListener(this );
    }

    @Override
    public void onClick(View view) {
        switch (view.getId())
        {
            case R.id.imageView4:
                finish();
                break;
        }
    }
}