package com.example.bakery;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class DetailItem extends AppCompatActivity implements View.OnClickListener {
    TextView tv_item,tv_ingredient,tv_price;
    ImageView iv_item,imageView2;
    Button button3;
String itemName,itemPrice,itemIngredient;
    private ArrayList<DataItems> dataItems=new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_detail_item);
        initViews();


        itemName=getIntent().getStringExtra("itemname");
        itemPrice=getIntent().getStringExtra("itemprice");
        itemIngredient=getIntent().getStringExtra("itemingredient");
        int imgID = this.getResources().getIdentifier(getIntent().getStringExtra("itemimage"),"drawable",getPackageName());
        iv_item.setImageResource(imgID);
        setvalues();
        imageView2.setOnClickListener(this);
        button3.setOnClickListener(this);

        Toast.makeText(DetailItem.this,itemPrice,Toast.LENGTH_SHORT).show();
    }

    private void setvalues() {
        tv_item.setText(itemName);
        tv_price.setText(itemPrice);
        tv_ingredient.setText(itemIngredient);

    }

    private void initViews() {
        tv_item=findViewById(R.id.tv_item);
        tv_ingredient=findViewById(R.id.tv_ingredients);
        tv_price=findViewById(R.id.tv_price);
        iv_item=findViewById(R.id.iv_item);
        imageView2=findViewById(R.id.imageView2);
        button3=findViewById(R.id.button3);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId())
        {
            case R.id.imageView2:
                finish();
                break;
            case R.id.button3:

                CartUtility.addItem(new DataItems(itemName,getIntent().getStringExtra("itemimage"),Double.parseDouble(itemPrice),itemIngredient));
                Toast.makeText(DetailItem.this,"Product added to cart",Toast.LENGTH_SHORT).show();
                finish();
                break;
        }
    }
}