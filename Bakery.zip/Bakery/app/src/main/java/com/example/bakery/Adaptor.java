package com.example.bakery;

import android.content.Context;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class Adaptor extends BaseAdapter {
    private ArrayList<DataItems> dataItems;
    private LayoutInflater inflater;

    public Adaptor(Context context, ArrayList<DataItems> dataItems) {
        this.dataItems = dataItems;
        inflater=LayoutInflater.from(context);
    }
    
    @Override
    public int getCount() {
        return dataItems.size();
    }

    @Override
    public Object getItem(int position) {
        return dataItems.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        String itemName;
        if(convertView ==null) {
            convertView = inflater.inflate(R.layout.list_row, null);
            holder = new ViewHolder();
            holder.name = convertView.findViewById(R.id.txtname);
            holder.img = convertView.findViewById(R.id.imageView3);
            holder.btnAdd = convertView.findViewById(R.id.btnplus);
            convertView.setTag(holder);
        }
        else
            holder = (ViewHolder) convertView.getTag();

        itemName=dataItems.get(position).getProdName();
        holder.name.setText(itemName);
        int imgID = convertView.getResources().getIdentifier(dataItems.get(position).getProImage(),"drawable",inflater.getContext().getPackageName());
        holder.img.setImageResource(imgID);
        holder.btnAdd.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                CartUtility.addItem(dataItems.get(position));
                ((MainActivity) v.getContext()).itemcount();

            }
        });
        return convertView;
    }

    static class ViewHolder{
        private ImageView img;
        private TextView name;
        private Button btnAdd;
    }
}
