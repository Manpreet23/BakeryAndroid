package com.example.bakery;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class LoginPage extends AppCompatActivity implements View.OnClickListener {

    EditText etName,etCity,etPlace,etFav;
    Button btnSubmit;
    TextView txtAbout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_page);
        getSupportActionBar().hide();
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);

        etName=findViewById(R.id.etname);
        etCity=findViewById(R.id.etcity);
        etPlace=findViewById(R.id.etplace);
        etFav=findViewById(R.id.etfav);
        btnSubmit=findViewById(R.id.btnsubmit);
        txtAbout=findViewById(R.id.txtabout);

        txtAbout.setOnClickListener(this);
        btnSubmit.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {

       switch (v.getId())
       {
           case R.id.btnsubmit:
               if (etName.getText().toString().equals(""))
               {
                   Toast.makeText(LoginPage.this,"Please enter name",Toast.LENGTH_SHORT).show();
               }
               else if (etCity.getText().toString().equals(""))
               {
                   Toast.makeText(LoginPage.this,"Please enter city",Toast.LENGTH_SHORT).show();
               }
               else if (etPlace.getText().toString().equals(""))
               {
                   Toast.makeText(LoginPage.this,"Please enter place",Toast.LENGTH_SHORT).show();
               }
               else if (etFav.getText().toString().equals(""))
               {
                   Toast.makeText(LoginPage.this,"Please enter favourite item",Toast.LENGTH_SHORT).show();
               }
               else
               {
                   Intent home = new Intent(LoginPage.this,MainActivity.class);
                   home.putExtra("name",etName.getText().toString());
                   startActivity(home);

               }
               break;

           case R.id.txtabout:

               Intent about = new Intent(LoginPage.this,About.class);

               startActivity(about);
               break;
       }

    }

}