package com.example.bakery;

public class DataItems {

    private String prodName;
    private String proImage;
    private double prodPrice;
    private String prodIngredients;

    public DataItems(String prodName, String proImage,double prodPrice,String prodIngredients) {
        this.prodName = prodName;
        this.proImage = proImage;
        this.prodPrice=prodPrice;
        this.prodIngredients=prodIngredients;
    }

    public String getProdName() {
        return prodName;
    }

    public void setProdName(String prodName) {
        this.prodName = prodName;
    }

    public String getProImage() {
        return proImage;
    }

    public void setProImage(String proImage) {
        this.proImage = proImage;
    }

    public String getProdIngredients() {
        return prodIngredients;
    }
    public double getProdPrice() {
        return prodPrice;
    }

}
