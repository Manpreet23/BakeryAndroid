package com.example.bakery;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.ArrayList;

public class AdapterCart extends BaseAdapter {
     private LayoutInflater inflater;
     ArrayList<DataItems> itemsCarts;


    public AdapterCart(Context context, ArrayList<DataItems> itemsCarts){
        this.itemsCarts=itemsCarts;
        inflater=LayoutInflater.from(context);
    }
    @Override
    public int getCount() {
        return itemsCarts.size();
    }

    @Override
    public Object getItem(int position) {
        return itemsCarts.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View view, ViewGroup parent) {
        ViewHolder1 viewHolder1;
        String itemName;
        if(view ==null) {
            view = inflater.inflate(R.layout.list_cart_row, null);
            viewHolder1 = new ViewHolder1();
            viewHolder1.items = view.findViewById(R.id.items);
            viewHolder1.iv_product = view.findViewById(R.id.iv_product);
            view.setTag(viewHolder1);
        }
        else
            viewHolder1 = (ViewHolder1) view.getTag();
            itemName=itemsCarts.get(position).getProdName();
            viewHolder1.items.setText(itemName);
            int imgID = view.getResources().getIdentifier(itemsCarts.get(position).getProImage(),"drawable",inflater.getContext().getPackageName());
            viewHolder1.iv_product.setImageResource(imgID);
        return view;
    }
    static class ViewHolder1{
        private TextView items;
        ImageView iv_product;
    }
}
