package com.example.bakery;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class Cart extends AppCompatActivity implements View.OnClickListener {
    ImageView imgBack;
    ListView lvItemsAdded;
TextView tv_amount;
Button btn_cancel,btn_placeOrder;
double totalPrice=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_cart);
        lvItemsAdded=findViewById(R.id.lvItemsAdded);
        imgBack=findViewById(R.id.imgBack);
        btn_cancel=findViewById(R.id.button2);
        btn_placeOrder=findViewById(R.id.button);
        tv_amount=findViewById(R.id.tv_amount);

        btn_cancel.setOnClickListener(this);
        btn_placeOrder.setOnClickListener(this);


        lvItemsAdded.setAdapter(new AdapterCart(this,CartUtility.getItem()));

        for (int i=0;i<CartUtility.getItem().size();i++)
        {
            totalPrice=totalPrice+CartUtility.getItem().get(i).getProdPrice();
        }
        tv_amount.setText(totalPrice+"");
        imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Cart.this,MainActivity.class));
            }
        });
    }

    @Override
    public void onClick(View view) {
        switch (view.getId())
        {
            case R.id.button2:
                CartUtility.getItem().clear();
                Toast.makeText(Cart.this,"Order cancelled",Toast.LENGTH_SHORT).show();
                finish();
                break;

            case R.id.button:
                CartUtility.getItem().clear();
                Intent cart=new Intent(Cart.this,Thanks.class);
                startActivity(cart);
                finish();
                break;
        }
    }
}