package com.example.bakery;

import java.util.ArrayList;

public class CartUtility {
    public static ArrayList<DataItems> itemsCarts=new ArrayList<>();
    //double price

    public static void addItem(DataItems dataItems){
        itemsCarts.add(dataItems);
    }
    public static ArrayList<DataItems> getItem(){
        return itemsCarts;
    }
}
